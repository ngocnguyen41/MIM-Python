def square_of_integers(x):
    return x**2

print (f"(-3)^2 = {square_of_integers(-3)}")   # (-3)^2 = 9
print (f"3^2 = {square_of_integers(3)}")    # 3^2 = 9
print (f"0^2 = {square_of_integers(0)}")   # 0^2 = 0

