# Infinite loop
num = 1
while num != 0:
    num += 1
    