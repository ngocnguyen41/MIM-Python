"""
Theo meme có thể hiểu:
    +) "while (not edge){ run();}": xét điều kiện của while xong mới chạy run 
    nên khi không còn thỏa mãn điều kiện thì while sẽ dừng không chạy run.
    +) Còn "do{ run();} while (not edge);": chạy run xong mới xét điều kiện
    nên khi không còn thỏa mãn điều kiện run vẫn chạy.
"""