"""
Câu hỏi:
a) VS Code là một phần mềm mã nguồn mở, đúng hay sai? Vì sao?
b) Chỉ ra ít nhất hai text editor khác có chức năng tương tự VS Code.
c) Giải thích ý nghĩa của meme sau

"""

"""
Trả lời:
a) VS Code là một phần mềm mã nguồn sai, đúng vì: 
    VS Code của microsoft yêu cầu giấy phép phần mềm thì mới thay đổi và tái phân phối phần mềm nguồn mở.

b) Text editor khác có chức năng tương tự VS Code: Vim; Notepad++; Atom; Sublime Text...

c) Ý nghĩa meme: khi Tim Pope được mọi người yêu cầu giới thiệu về text editor, ảnh đầu khi rút kiếm ra khỏi bao hiện chữ "VI"
    mở đầu tưởng giới thiệu về VIM nhưng thực ra là VISUAL STUDIO CODE.
"""