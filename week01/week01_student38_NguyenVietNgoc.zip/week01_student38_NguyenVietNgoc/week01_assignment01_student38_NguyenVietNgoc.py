"""
Câu hỏi:
a) Ngôn ngữ lập trình Python được tạo ra bởi ai và vào thời gian nào?
b) Vì sao ngôn ngữ lập trình Python lại được đặt tên như vậy?
c) Tính tới ngày 13/07/2022, phiên bản Python mới nhất được phát hành là phiên bản nào?
"""

"""
Trả lời:
a) Ngôn ngữ lập trình Python được tạo ra bởi Guido Van Rossum vào tháng 2 năm 1991.

b) Ngôn ngữ lập trình Python lại được đặt tên như vậy, vì:
    Guido van Rossum , tác giả của ngôn ngữ lập trình Python đã tìm thấy nguồn cảm hứng khi xem chương trình 
    của nhóm hài nổi tiếng người Anh: Monty Python và với có tên gọi sáng tạo dựa trên các tiêu chí như ngắn, độc đáo và một chút bí ẩn
    vì vậy anh ấy quyết định gọi ngôn ngữ này là Python .

c) Tính tới ngày 13/07/2022, phiên bản Python mới nhất được phát hành là phiên bản Python 3.10.5
"""